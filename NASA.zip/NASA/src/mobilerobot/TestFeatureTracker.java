package mobilerobot;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

/* This class is for testing FeatureTracker object
 * It will run all sample inputs and generate one Output
 * File "AllTestResult.txt" to show all test execution on each input file.
 * If the test sample input file has a sample output file,
 * the information of that output file will be shown as well
 * for comparison purpose.
 */
public class TestFeatureTracker {

    /*
     * @return the string line of output.txt file (output0.txt, output1.txt, etc...)
     * if file doesn't exist,return null string 
     */
	public static String readSampleOuputFile(String filePathName) {
		try {
			return new String(Files.readAllBytes(Paths.get(filePathName))); 
		}catch ( Exception ex) {
			//ignore exception as we may not have file to look
		}
		return null;
	}

	 /*
     * @return the List of feature angles on input file.
     * This list of feature angles are on many different clusters.
     */
	public static List<Double> readSampleInputFile(String filePathName) throws FileNotFoundException {
		FileReader file = new FileReader(filePathName);
		List<Double> listOfFeatureAngles = new ArrayList<Double>();
		try {    
			Scanner input = new Scanner(file);    
			input.useDelimiter(",");
			while (input.hasNext()) {
				listOfFeatureAngles.add(Double.valueOf(input.next()));
			}    
			input.close();

		} catch (Exception e) {    
			e.printStackTrace();    
		}

		return listOfFeatureAngles;
	}


	/*
     * Write contents to one single output file "TestResult.txt"
     */
	public static void writeToOutPutFile(StringBuilder contents) {
		try {
			String filePathName = System.getProperty("user.dir") +"/AllTestResult.txt";
			//generate different file but take the last 3 number of timestamp
            //filePathName = filePathName +"." + (System.currentTimeMillis()%1000;
			File file = new File(filePathName);
			if (!file.exists()) {
				file.createNewFile();
			} 
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(contents.toString());
			bw.close();

		} catch (IOException e) {
			e.printStackTrace();
		} 
	}
  
	/*
	 * Run all test cases
	 */
	public static void runAllTest (String [] testFiles) {
		//String[] testFiles = { "input0.txt", "input1.txt", "input2.txt","input3.txt", "input4.txt"};
		StringBuilder builder = new StringBuilder();
		for(String testFile:testFiles) {
			String filePathName = System.getProperty("user.dir") +"\\samples\\" + testFile;
			runTest(builder, filePathName);
		}
		//System.out.println(builder.toString());
		writeToOutPutFile(builder);

	}

	/*
	 * @return feature angles input file as a string with , separation
	 */
	public static String getInputContents(List<Double> featureAngles) {
		StringBuilder builder = new StringBuilder();
		int index =0;
		for ( double value:featureAngles) {
			builder.append(value);
			if(index++ !=featureAngles.size()-1)
				builder.append(",");
		}
		return builder.toString();
	}
	/*
	 * Run single test case on one input file
	 */
	public static void runTest(StringBuilder builder, String fileName) {

		try {
			List<Double> featureAngles = readSampleInputFile(fileName);
			FeatureTracker fTracker = new FeatureTracker(featureAngles);

			List<Double> centerAngles = fTracker.getAllClusterCenterAngles();

			builder.append("\n");
			builder.append("=========================RunTest: " + fileName);
			builder.append("\n\n");
			builder.append("INPUT: ").append(getInputContents(featureAngles));
			builder.append("\n\n");
			builder.append("  >TEST-OUTPUT: ");
			int index = 0;
			for ( double centerAngle:centerAngles) {

				builder.append(centerAngle);
				if (index++ != (centerAngles.size() -1))
					builder.append(",");
			}
			String outputName = fileName.replace("input",  "output");
			String outputSampleContent = readSampleOuputFile (outputName);
			if(outputSampleContent != null) {
				builder.append("\n");
				builder.append(">SAMPLE-OUTPUT: ").append(outputSampleContent);
			}
			else
				builder.append("\n");

		}catch ( FileNotFoundException ex) {
			ex.printStackTrace();
		}


	}

	/*
	 * main entry point
	 * we can pass any input file name for testing
	 * 
	 */
	public static void main(String[] args) {
		String[] testFiles =  { "input0.txt", "input1.txt", "input2.txt","input3.txt", "input4.txt"};
		if(args.length == 0)
			runAllTest(testFiles);
		else {
			runAllTest(args);
		}
	
	}


}
