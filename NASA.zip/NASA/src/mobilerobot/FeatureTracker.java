package mobilerobot;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
/*
 * FeatureTracker object takes inputs feature locations to find clusters
 * and the approximate center location of each cluster.
 */

public class FeatureTracker {

	private List<List<Double>> clusters = new ArrayList <List<Double>> ();

	/*ASSUMPTION(1)
      The max distance between 2 consecutive features on the same group 
      features[i] - features[i-1] should <=20.
      This is based on sample data test and condition of center angle point
      accuracy within 20 degrees.
	*/
	public static double MAX_DISTANCE_2FEATURES_IN_SAME_CLUSTER = 20.0;

	/*ASSUMPTION(2)
      We need at least 3 data points for better median calculation
      and reasonable consideration for a cluster.

	*/
	public static int MIN_NUMBER_FEATURES = 3; 

	/*ASSUMPTION(3):
	  If the feature angles are too close together, the angle spanning is calculated
      by differences between max and min( max_angle - min_angle) could be very small.
      Therefore, we can drop that cluster.
      The files input2.text and ouput2.txt demonstrate that we can drop a few features
      angles from 0.2, 0.2, 1.2, 3.1, 3.2, 4.1, 5.9 as the angle spanning is
      5.7 ( 5.9 - 0.2 = 5.7). But we can keep the cluster with feature angles
      spanning =9.5 (359.8 -350.3 = 9.5) for the set: 350.3,353.5,359.5,359.8.

	  With this sample test, we assume that the MIN_EXPANSION_RANGE =9.5. 
	  So the cluster is considered to use having a spanning
      max-feature-angles -min-features-angles >=MIN_EXPANSION_RANGE 

	*/
	public static double MIN_EXPANSION_RANGE =9.5;

	/*ASSUMPTION(4):
      All Clusters are in increasing order of features angle values.
      (ie: values[i] < values[i+1]�.)
      We exclude the case of cluster contain features in the border between the boundary of 360 degrees and 0 degree.
      (ie: 359.5 and 0.5 could be on the same cluster).
      This assumption makes simplicity for the problem and supports calculation of
      the above assumption

	 */



	/* 
	 * constructor
	 */
	public FeatureTracker(List<Double>features) {
		findClusters(features);
	}

	/* 
	 * @return the list of detected clusters
	 */
	public List<List<Double>> getClusters(){
		return clusters;
	}

	/* 
	 * @return the list of center angles of the clusters
	 */
	public List<Double> getAllClusterCenterAngles (){
		List<Double> centerAngles = new ArrayList <Double>();
		for(List<Double>cluster:clusters)
			centerAngles.add(getClusterCenterAngle(cluster));

		return centerAngles;
	}

	/* 
	 * @return center angle of a single cluster
	 *  (note: a single cluster contains a list of feature angles)
	 */
	public double getClusterCenterAngle(List<Double> cluster) {
		if(cluster == null || cluster.size () == 0)
			return 0.0; // 
		int size = cluster.size();

		//Find the median value
		//but the list starts index by 0, the index will relative from starting 0
		int midIndex = size/2;
		// even case: use the average value of 2 middle numbers
		if(size %2 == 0) {
			double median= (cluster.get(midIndex -1) + cluster.get(midIndex)) /2 ;
			return (getRoundOfOneDecimal(median));
		}
		//odd case: use the center number
		return cluster.get(midIndex);

	}

	/* 
	 * @return double value formated to one single decimal
	 *  
	 */
	private double getRoundOfOneDecimal (double value) {
		DecimalFormat dFormat = new DecimalFormat("#.#"); 
		return Double.valueOf(dFormat.format(value));
	}

	/*
	 * Check if cluster is valid to add to clusters list
	 * -only use the cluster that has at least 3 feature angles
	 * -only use the cluster that maxAngle-minAngle >=MIN_EXPANSION_RANGE
	 */
	private boolean isValidCluster(List<Double> cluster) {

		if(cluster != null && cluster.size() >=MIN_NUMBER_FEATURES) {
			double angleRangeOnCluster = cluster.get(cluster.size()-1) -cluster.get(0);
			if(angleRangeOnCluster >= MIN_EXPANSION_RANGE)
				return true;
		}
		return false;
	}
	/*
	 * Add a valid detected cluster to clusters list
	 */
	private void addClusterIfValid(List<Double> cluster) {
		if(isValidCluster(cluster)){
			clusters.add(cluster);
		}
	}
	/* 
	 * Detect clusters from the list of feature angles.
	 * with 3 assumptions mentioned on the top
	 * - only include the feature on same cluster if 
	 * distance of ith pos and previous of ith in the range MAX_DISTANCE_2FEATURES_IN_SAME_CLUSTER
	 * -only use the cluster has at least 3 feature angles
	 * -only use the cluster that maxAngle-minAngle >=MIN_EXPANSION_RANGE
	 */
	private void findClusters(List<Double> featureAngles){
		if(featureAngles == null || featureAngles.size() == 0) {
			System.out.println("ERROR: Empty Feature Angle Input");
			return;
		}

		List <Double> cluster = new ArrayList<Double>();
		double prev = featureAngles.get(0);
		cluster.add(prev);

		for (int i =1; i <featureAngles.size(); i++) {
			//Find a feature which is not part of the current cluster
			if((featureAngles.get(i)- prev )> MAX_DISTANCE_2FEATURES_IN_SAME_CLUSTER) {
				addClusterIfValid(cluster);
				//start a new cluster data set
				cluster = new ArrayList <Double>();
				prev = featureAngles.get(i);
				cluster.add(prev);
			}
			else {
				cluster.add(featureAngles.get(i));
				prev = featureAngles.get(i);
			}

		}
		//after for loop, we may have previous detected cluster which is not yet
		//added into clusters.
		addClusterIfValid(cluster);

	}

}